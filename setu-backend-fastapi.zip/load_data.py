from __future__ import annotations

import os
from pathlib import Path

import pandas as pd
from dotenv import load_dotenv

try:
    import pyTigerGraph as tg  # type: ignore
except Exception:
    tg = None


load_dotenv()

DATA_DIR = Path(__file__).parent / "data"


def read_csv_or_fail(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(f"Missing CSV file: {path}")
    return pd.read_csv(path)


def validate_columns(df: pd.DataFrame, expected: list[str], name: str) -> None:
    missing = [c for c in expected if c not in df.columns]
    if missing:
        raise ValueError(f"{name} missing columns: {missing}")


def main() -> None:
    files = {
        "warehouses": DATA_DIR / "warehouses.csv",
        "villages": DATA_DIR / "villages.csv",
        "suppliers": DATA_DIR / "suppliers.csv",
        "road_edges": DATA_DIR / "road_edges.csv",
        "air_edges": DATA_DIR / "air_edges.csv",
        "supplies_edges": DATA_DIR / "supplies_edges.csv",
    }

    warehouse_df = read_csv_or_fail(files["warehouses"])
    village_df = read_csv_or_fail(files["villages"])
    supplier_df = read_csv_or_fail(files["suppliers"])
    road_df = read_csv_or_fail(files["road_edges"])
    air_df = read_csv_or_fail(files["air_edges"])
    supplies_df = read_csv_or_fail(files["supplies_edges"])

    validate_columns(
        warehouse_df,
        ["id", "name", "lat", "lng", "capacity", "operational", "stock_medicine", "stock_food", "stock_blanket"],
        "warehouses.csv",
    )
    validate_columns(
        village_df,
        ["id", "name", "lat", "lng", "pop", "urgencylevel", "request_type", "wait_time"],
        "villages.csv",
    )
    validate_columns(supplier_df, ["id", "name"], "suppliers.csv")
    validate_columns(road_df, ["from_id", "to_id", "cost", "dist", "time", "isblocked"], "road_edges.csv")
    validate_columns(air_df, ["from_id", "to_id", "cost", "dist", "time", "isblocked"], "air_edges.csv")
    validate_columns(supplies_df, ["from_id", "to_id", "cost", "dist", "time", "isblocked"], "supplies_edges.csv")

    print("CSV validation passed")

    if tg is None:
        print("pyTigerGraph is not available. Skipping upload.")
        return

    host = os.getenv("TG_HOST")
    graph = os.getenv("TG_GRAPHNAME")
    token = os.getenv("TG_TOKEN")

    if not host or not graph:
        print("TigerGraph env vars not configured. Skipping upload.")
        return

    conn = tg.TigerGraphConnection(host=host, graphname=graph, apiToken=token)

    # Upsert vertices
    warehouse_vertices = {
        row["id"]: {
            "name": {"value": row["name"]},
            "lat": {"value": float(row["lat"])},
            "lng": {"value": float(row["lng"])},
            "capacity": {"value": int(row["capacity"])},
            "operational": {"value": bool(row["operational"])},
            "stock_medicine": {"value": int(row["stock_medicine"])},
            "stock_food": {"value": int(row["stock_food"])},
            "stock_blanket": {"value": int(row["stock_blanket"])},
        }
        for _, row in warehouse_df.iterrows()
    }
    village_vertices = {
        row["id"]: {
            "name": {"value": row["name"]},
            "lat": {"value": float(row["lat"])},
            "lng": {"value": float(row["lng"])},
            "pop": {"value": int(row["pop"])},
            "urgencylevel": {"value": float(row["urgencylevel"])},
            "request_type": {"value": row["request_type"]},
            "wait_time": {"value": float(row["wait_time"])},
        }
        for _, row in village_df.iterrows()
    }
    supplier_vertices = {
        row["id"]: {"name": {"value": row["name"]}}
        for _, row in supplier_df.iterrows()
    }

    conn.upsertVertices("Warehouse", warehouse_vertices)
    conn.upsertVertices("Village", village_vertices)
    conn.upsertVertices("Supplier", supplier_vertices)

    def upsert_edge(df: pd.DataFrame, edge_type: str, from_type: str, to_type: str) -> None:
        edge_data = {}
        for _, row in df.iterrows():
            from_id = row["from_id"]
            to_id = row["to_id"]
            if from_id not in edge_data:
                edge_data[from_id] = {}
            if edge_type not in edge_data[from_id]:
                edge_data[from_id][edge_type] = {}
            if to_type not in edge_data[from_id][edge_type]:
                edge_data[from_id][edge_type][to_type] = {}

            edge_data[from_id][edge_type][to_type][to_id] = {
                "cost": {"value": float(row["cost"])},
                "dist": {"value": float(row["dist"])},
                "time": {"value": float(row["time"])},
                "isblocked": {"value": bool(row["isblocked"])},
            }

        conn.upsertEdges(from_type, edge_type, to_type, edge_data)

    upsert_edge(road_df, "ROADCONNECTS", "Warehouse", "Village")
    upsert_edge(air_df, "AIRCONNECTS", "Warehouse", "Village")
    upsert_edge(supplies_df, "SUPPLIES", "Supplier", "Warehouse")

    print("TigerGraph upsert complete")


if __name__ == "__main__":
    main()
